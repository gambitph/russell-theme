jQuery(document).ready(function($) {
 
  $(".russell-content-large").owlCarousel({
  
      autoPlay: 3000, //Set AutoPlay to 3 seconds
      singleItem: true
// pagination: true,
      //items : 1
      // itemsDesktop : [1199,3],
      // itemsDesktopSmall : [979,3]
 
  });
  console.log(' carousel active.');
 
});